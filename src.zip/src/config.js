const CONFIG = {
    GOOGLE_KEY: "AIzaSyBlM0wh8d0MVPg3L1pGenNQHSnXjkKIE_I",
    CENSUS_KEY: "49447b11300c1ff72900f8c8449dcad8c4350cb6"
  };
  
export default CONFIG;