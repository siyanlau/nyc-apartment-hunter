const sum = (a, b) => a+b;

module.exports = sum;